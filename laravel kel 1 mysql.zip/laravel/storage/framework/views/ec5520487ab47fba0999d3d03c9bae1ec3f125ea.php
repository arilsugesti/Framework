

<form method="POST" action="<?php echo e(url('pelanggan/simpan')); ?>">
    <?php echo e(csrf_field()); ?>

    Nama : <input type="text" name="name"><br>
    Usia : <input type="number" name="umur">
    
    <button> klik</button>

</form><?php /**PATH C:\xampp\htdocs\laravel\resources\views/Pelanggan/form.blade.php ENDPATH**/ ?>