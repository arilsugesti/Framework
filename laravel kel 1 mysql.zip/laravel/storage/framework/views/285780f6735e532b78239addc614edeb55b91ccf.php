
<a href=<?php echo e(url('pelangganform')); ?>> Klik disini</a>
<?php /**PATH C:\xampp\htdocs\laravel\resources\views/Pelanggan/index.blade.php ENDPATH**/ ?>