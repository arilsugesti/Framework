Nama : {{$namapelanggan}}
Umur : {{$usia}}

@if ($usia < 12)
    @php( $ket="Anak")
@elseif ($usia < 17)
        @php($ket="Remaja")
@elseif ($usia < 22)
            @php($ket="Dewasa muda")
@elseif ($usia < 35)
                @php($ket="Dewasa matang")
@elseif ($usia > 35)
                @php($ket="Tua")
@endif

Keterangan : {{$ket}}
@for ($i=1; $i <= $usia; $i++)
{{$i}}
@endfor