<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/fahmi', function () {
    return view('coba');
});

Route::get('tampil/{id}', function ($id) {
    echo "Ini adalah".id;
});

Route::get('/pelanggan', 'Pelanggan@index' );
Route::get('/pelangganform', 'Pelanggan@form');
Route::get('/ket', 'Pelanggan@ket');
Route::post('/pelanggan/simpan', 'Pelanggan@simpan');

